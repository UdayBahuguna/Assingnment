i=0
n=20
a,b=0,1
while(i<n):
    print(a, end=" ")
    a,b=b,a+b
    i=i+1
