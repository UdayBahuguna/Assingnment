def multiply(list1):
    for i in list1:
        x = i*i
    return x


print("result is: ",multiply([1,2,3,4,5]))