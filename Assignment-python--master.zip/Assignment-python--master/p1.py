def volumeOfSphere(r):
    pi= 3.14
    v = 4.0/3.0 * pi * r **3
    print("Volume of sphere is: ",v)

radius = int(input("Enter radius"))
volumeOfSphere(radius)
